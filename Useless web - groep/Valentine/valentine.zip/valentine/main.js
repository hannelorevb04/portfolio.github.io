const yesLink = document.querySelector("#yesLink");
const noLink = document.querySelector("#noLink");
const question = document.querySelector(".question_1");
const container = document.querySelector(".container");
const sorry = document.querySelector("#sorryScreen");

noLink.addEventListener("click", function (event) {
  event.preventDefault();

  if (noLink.textContent === "NO") {
    yesLink.style.fontSize = "50px";
    noLink.textContent = "why not?";

  } else if (noLink.textContent === "why not?") {
    yesLink.style.fontSize = "85px";
    noLink.textContent = "are you sure?";

  } else if (noLink.textContent === "are you sure?") {
    yesLink.style.fontSize = "125px";
    noLink.textContent = "are you very very sure?";

  } else if (noLink.textContent === "are you very very sure?") {
    yesLink.style.fontSize = "175px";
    noLink.textContent = "I have a gift for you";

  } else if (noLink.textContent === "I have a gift for you") {
    yesLink.style.fontSize = "250px";
    noLink.textContent = "You will love it!";

  } else if (noLink.textContent === "You will love it!") {
    yesLink.style.fontSize = "400px";
    noLink.textContent = "I have planned our date :)";
    yesLink.style.marginLeft = "20%";
  }

  else if (noLink.textContent === "I have planned our date :)") {
    yesLink.style.fontSize = "600px";
    noLink.textContent = "Please...";
    yesLink.style.marginLeft = "10%";
    yesLink.style.zIndex = "1";
    noLink.style.marginTop = "-200px";
  }

  else if (noLink.textContent === "Please...") {
    yesLink.style.fontSize = "1000px";
    noLink.textContent = "SAY YES!";
    yesLink.style.marginLeft = "10%";
    yesLink.style.zIndex = "1";
    noLink.style.marginTop = "-200px";
  }
});

document.getElementById("yesLink").addEventListener("click", function(event) {
  event.preventDefault();

  question.style.display = "none";
  yesLink.style.display = "none";
  noLink.style.display = "none";
  container.style.display = "none";

  sorry.style.display = "block";
});


